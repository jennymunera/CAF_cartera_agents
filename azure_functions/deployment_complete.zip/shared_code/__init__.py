# Shared code module for Azure Functions
# Contains all shared utilities, processors, and schemas