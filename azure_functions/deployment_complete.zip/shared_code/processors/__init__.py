# Processors module for Azure Functions
# Contains all document processing logic